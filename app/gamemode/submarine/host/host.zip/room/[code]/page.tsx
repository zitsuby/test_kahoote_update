"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Users, Settings, Maximize, Minimize, Unlock, Volume2, VolumeX } from "lucide-react"
import { useParams, useSearchParams, useRouter } from "next/navigation"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import QRCode from "react-qr-code"

// Dummy player data
const dummyPlayers = [
  { id: "1", nickname: "Captain_Blue", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=1" },
  { id: "2", nickname: "SeaExplorer", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=2" },
  { id: "3", nickname: "DeepDiver", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=3" },
  { id: "4", nickname: "OceanMaster", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=4" },
]

export function FullscreenButton() {
  const [isFullscreen, setIsFullscreen] = useState(false)

  const toggleFullscreen = () => {
    const elem = document.documentElement

    if (!document.fullscreenElement) {
      elem.requestFullscreen?.()
    } else {
      document.exitFullscreen?.()
    }
  }

  // Detect fullscreen changes (ESC, browser button, etc.)
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)

    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
    }
  }, [])

  return (
    <button onClick={toggleFullscreen} className="flex items-center">
      {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
    </button>
  )
}

export default function HostRoomPage() {
  const params = useParams()
  const searchParams = useSearchParams()
  const router = useRouter()

  const roomCode = params.code as string
  const quizType = searchParams.get("quiz")
  const gameTime = searchParams.get("time")
  const roomName = searchParams.get("name")

  const [players, setPlayers] = useState(dummyPlayers)

  const startGame = () => {
    // Clear any existing countdown flag
    localStorage.removeItem(`countdown-done-${roomCode}`)
    // Redirect to countdown page
    router.push(`/host/countdown/${roomCode}`)
  }

  const [showQRPopup, setShowQRPopup] = useState(false)
  const gamePIN = "121312"
  const formattedGamePin = gamePIN.replace(/(\d{3})(\d{3})/, "$1 $2")

  const [muted, setMuted] = useState(false)

  const toggleMute = () => {
    setMuted((prev) => !prev)
    const audio = document.getElementById("bg-audio") as HTMLAudioElement
    if (audio) {
      audio.muted = !audio.muted
    }
  }

  return (
    <div className="min-h-screen overflow-hidden">
      <audio id="bg-audio" src="/lobby-submarine.mp3" autoPlay loop />
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('/submarine-card.svg')`,
        }}
      />

      {/* Main content */}
      <div className="relative z-20 min-h-screen flex flex-col">
        {/* Header with Game PIN */}
        <div className="flex justify-center items-start p-5 gap-4">
          {/* Game PIN Card */}
          <Card className="bg-transparent border-0">
            <CardContent className="p-1 rounded-xl text-center">
              <div className="flex gap-2">
                <div className="bg-white p-4 px-6 rounded-sm text-left">
                  <h1 className="font-semibold">Game PIN:</h1>
                  <h1
                    className="text-5xl font-black cursor-pointer hover:opacity-70 transition"
                    onClick={() => {
                      navigator.clipboard.writeText(gamePIN)
                    }}
                  >
                    {formattedGamePin}
                  </h1>
                </div>
                <div className="bg-white p-1 rounded-sm cursor-pointer" onClick={() => setShowQRPopup(true)}>
                  <QRCode value={`https://play.kahoot.it/v2/?pin=${gamePIN}`} size={100} />
                </div>
                {showQRPopup && (
                  <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
                    <div className="p-6 rounded-xl shadow-xl flex flex-col items-center gap-4">
                      <div className="bg-white p-4 px-6 rounded-sm text-left">
                        <h1 className="font-semibold">Game PIN:</h1>
                        <h1
                          className="text-7xl font-black cursor-pointer hover:opacity-70 transition"
                          onClick={() => {
                            navigator.clipboard.writeText("847 326")
                          }}
                        >
                          847 326
                        </h1>
                      </div>
                      <div className="p-3 rounded-lg bg-white">
                        <QRCode value={`https://play.kahoot.it/v2/?pin=${gamePIN}`} size={325} />
                      </div>
                      <button
                        onClick={() => setShowQRPopup(false)}
                        className="mt-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition"
                      >
                        Tutup
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main game area */}
        <div className="flex items-center justify-end mr-4 gap-2">
          <Button variant="outline" size="icon" className="bg-white/90 border-2 border-gray-300 hover:bg-white">
            <Unlock className="w-5 h-5" />
          </Button>
          <Button
            onClick={startGame}
            disabled={players.length === 0}
            className="bg-white text-gray-800 hover:bg-gray-100 font-semibold py-3 text-lg border-2 border-gray-300"
          >
            Start
          </Button>
        </div>
        <div className="flex-1 flex items-center justify-center px-6">
          <div className="relative w-full max-w-4xl">
            {/* Submarine */}
            <div className="flex">
              {/* Players on submarine */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="grid grid-cols-2 gap-4 mb-10">
                  {players.slice(0, 4).map((player, index) => (
                    <div key={player.id} className="flex flex-col items-center">
                      <Avatar className="w-12 h-12 border-2 border-white shadow-lg">
                        <AvatarImage src={player.avatar || "/placeholder.svg"} />
                        <AvatarFallback className="bg-blue-500 text-white">{player.nickname[0]}</AvatarFallback>
                      </Avatar>
                      <span className="text-white text-sm font-medium mt-1 bg-black/50 px-2 py-1 rounded">
                        {player.nickname}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Additional players grid */}
            {players.length === 0 && (
              <div className="flex justify-center ">
                <p className="bg-blue-600 p-1 px-2 rounded-sm text-2xl font-medium text-white">
                  Waiting for participants
                </p>
              </div>
            )}
            {players.length > 4 && (
              <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4 mt-8">
                {players.slice(4).map((player) => (
                  <div key={player.id} className="flex flex-col items-center">
                    <Avatar className="w-12 h-12 border-2 border-white shadow-lg">
                      <AvatarImage src={player.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="bg-blue-500 text-white">{player.nickname[0]}</AvatarFallback>
                    </Avatar>
                    <span className="text-white text-xs font-medium mt-1 bg-black/50 px-2 py-1 rounded truncate max-w-[80px]">
                      {player.nickname}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Bottom info */}
        <div className="flex p-2 px-5 gap-2 text-white justify-end items-center">
          <div className="flex items-center gap-1 bg-black p-2 rounded-lg">
            <Users className="w-5 h-5" />
            <span className="font-semibold text-sm">{players.length}</span>
          </div>
          <div className="flex items-center gap-3 p-2 text-white bg-black backdrop-blur-sm rounded-lg">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMute}
              className="hover:text-white hover:bg-black cursor-pointer"
              asChild
            >
              {muted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </Button>
            <Settings className="w-5 h-5 text-white cursor-pointer" />
            <Button asChild>
              <FullscreenButton />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
